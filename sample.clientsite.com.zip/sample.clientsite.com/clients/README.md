# Sample Client Website

This folder is solely for hosting the ```.htpasswd``` file which contains usernames and passwords for client downloads.

It uses the ```.htaccess``` file in the main client website.

