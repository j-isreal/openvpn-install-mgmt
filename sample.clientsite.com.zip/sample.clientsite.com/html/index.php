<?php
// simply redirect any requests to the website to another website or URL
// useful if you don't want people to view the client config site, and send them to your VPN site or FAQ
header("Location: https://www.yoursite.com/");
?>
