<?php
// sends any user request to this folder to another site
// you can also use the err404.html file in the root of the website
        header("Location: https://www.google.com/");
?>
