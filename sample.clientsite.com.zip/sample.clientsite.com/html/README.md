# Sample Client Website

This is a sample of the /var/www/sample.clientsite.com/html sample client site.

The index.php file simply redirects any requests to another site.  

This client site is setup to only process downloads of client configuration files for OpenVPN (.ovpn files) that have been zipped with a password and then protected with ```htpasswd``` and an ```.htacess``` file.
